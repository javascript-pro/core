---
order: 1
title: Abgeschottet KI
description: ring‑fenced LLM
slug: /work/abgeschottet-ki
icon: work
image: /png/n64/punk.png
---

> A ring‑fenced LLM is like having the power of AI inside a locked room.
It can process sensitive documents and assist with legal work, but nothing ever leaves the firm’s secure network.

What Does It Mean to Ring‑Fence an LLM So That No Data Leaves the Internal Network?
When we say an AI or Large Language Model (LLM) is ring‑fenced, we mean it is completely contained within a secure environment — with no pathway for data to escape to the public internet.

> Technically, this involves: Running the LLM on internal servers or approved cloud infrastructure. The model is hosted on hardware or a private cloud that the firm controls, rather than a public AI platform thus

### Blocking external connections
Network firewalls and security policies are set so the LLM cannot send or receive data beyond the firm’s internal network.

### Using local storage only
Any prompts, documents, or outputs are stored within the firm’s own systems. Nothing is uploaded to third‑party servers.

### Strict access controls
Only authorised staff can use the LLM, and their activity can be logged and audited.

### No training on client data unless approved
The model’s learning process is frozen or carefully managed so sensitive information isn’t used to improve the model in ways that leave the secure