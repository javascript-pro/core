---
order: 40
title: Abgeschottet KI
description: Hardware
slug: /work/abgeschottet-ki/hardware
icon: work
image: /png/n64/punk.png
---

Have a think about what hardware you want. Remember that this is a low investment, quick to implement solution that can be easily scaled when needed

If you have, say 100 users from whom an average concurrent use is max 10, then we'll set you up on a Dell Double'ard Blade (What is a cheap, easy to get hold of server from a good brand like Dell?)

