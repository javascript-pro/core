---
order: 10
title: Abgeschottet KI
description: Where is the need for this?
slug: /work/abgeschottet-ki/why
icon: work
image: /png/n64/punk.png
---

Explain why and how Abgeschottet KI solves the business problem